package com.cts.freelancer.service;

public interface AdminUpdateService {
	
	public boolean updatePhone(String uphone, int adminId);
	public boolean updatePassword(String upass,int adminId);
}
