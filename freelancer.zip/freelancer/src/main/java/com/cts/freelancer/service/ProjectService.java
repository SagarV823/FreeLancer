package com.cts.freelancer.service;

import java.util.List;

import com.cts.freelancer.bean.Project;

public interface ProjectService {

	public boolean registerProject(Project project,int adminId);
	public boolean updateProjectSkills(int pid,List<String> skillList);
	public boolean deleteProject(int projectId);
	public boolean refreshProject(int projectId);
}
