package com.cts.freelancer.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.Proposals;
import com.cts.freelancer.service.AdminLoginService;
import com.cts.freelancer.service.LancerLoginService;
import com.cts.freelancer.service.ProjectService;

@Controller
@Scope("session")
public class AdminController {
		
	@Autowired
	AdminLoginService adminLoginService;
	
	@Autowired
	ProjectService projectService;
	
	@Autowired
	LancerLoginService lancerService;
	
	static Logger logger = Logger.getLogger(AdminController.class);
    	
	@RequestMapping(value="registerAdmin",method=RequestMethod.GET)
    public ModelAndView registerAdmin(@ModelAttribute Admin admin)
    {	logger.info("Validating Inputs...");
		boolean flagName=false,flagEmail=false,flagPhone=false;
		ModelAndView modelAndView=new ModelAndView();

		String firstName=admin.getFirstName();
		String lastName=admin.getLastName();
		String phoneNumber=admin.getPhoneNumber();
		
		
		boolean allFirstLetters = firstName.chars().allMatch(Character::isLetter);
		boolean allLastLetters = lastName.chars().allMatch(Character::isLetter);
		
		boolean result=adminLoginService.authenticateAdminExistence(admin.getEmailId());
	
		if(result==true){
			logger.info("Validation Failed");
			logger.info("**Email Id already exists");
			modelAndView.addObject("statusemail", "**Email Id already exists, try with different email id");flagEmail=true;}
		
		
		if(!allLastLetters){
			flagName=true;
			logger.info("Validation Failed");
			logger.info("**Last Name cannot contain number or special characters");
			modelAndView.addObject("statuslastname","**Last Name cannot contain number or special characters");
			}
		if(!allFirstLetters){
				flagName=true;
				logger.info("Validation Failed");
				logger.info("**First Name cannot contain number or special characters");
				modelAndView.addObject("statusfirstname","**First Name cannot contain number or special characters");
			}
		
		
		if((phoneNumber.length()>10||phoneNumber.length()<10)||(phoneNumber.contains("[a-zA-Z]+"))){
			
			if(phoneNumber.length()>10||phoneNumber.length()<10){
				
				if(phoneNumber.length()>10){
					flagPhone=true;
					logger.info("Validation Failed");
					logger.info("**Phone Number cannot be greater than 10 digits");
					modelAndView.addObject("statusphone","**Phone Number cannot be greater than 10 digits");
					}
				else if(phoneNumber.length()<10)
					{flagPhone=true;
					logger.info("Validation Failed");
					logger.info("**Phone Number cannot be less than 10 digits");
					modelAndView.addObject("statusphone","**Phone Number cannot be less than 10 digits");
					
					}
				}
			else if(phoneNumber.contains("[a-zA-Z]+"))
			{flagPhone=true;
			logger.info("Validation Failed");
			logger.info("**Phone Number cannot contain alphabet or special characters");
				modelAndView.addObject("statusphone","**Phone Number cannot contain alphabet or special characters");
				
			}
		}
		
	
		logger.debug("Aflag Name : "+flagName);
		logger.debug("Aflag Email : "+flagEmail);
		logger.debug("Aflag Phone : "+flagPhone);
		
	
	if(flagName==false&&flagEmail==false&&flagPhone==false)
	{	
		boolean registerAdmin=adminLoginService.registerAdmin(admin);
		if(registerAdmin)
			logger.info("Registration successful !");
		else
			logger.warn("Registration failed ! Check EmailId or Password ...");
		modelAndView.addObject("Registerstatus","Successfully registered! Proceed to login Page!");
		
		
	}
	modelAndView.setViewName("adminRegisterForm");
	return modelAndView;	
    }
	
	  @RequestMapping(value="adminLoginAuth",method=RequestMethod.POST)
	    public ModelAndView adminAuthentication(@RequestParam("emailId") String emailId,@RequestParam("password") String password,HttpServletRequest request)
	    {	logger.info("Credential A Authenticating ...");	      	      
		  	
		  	ModelAndView modelAndView=new ModelAndView();
	    	boolean result=adminLoginService.authenticate(emailId, password);
	    	HttpSession session=request.getSession();
	    	session.setAttribute("emailId", emailId);
	    	Admin admin=adminLoginService.getAdmin(emailId);
	    	
	    	if(result)
	    	{	logger.info("Authentication Successful ...");	 
	    		int adminId=adminLoginService.getadminId(emailId);
	    		modelAndView.setViewName("adminWelcome");
	    		modelAndView.addObject("admin",admin);
	    	}
	    	else
	    	{	logger.warn("Authentication failed ! Wrong Email or Password ...");	
	    		modelAndView.addObject("status","Wrong Email or Password!");
				modelAndView.setViewName("adminLogin");
	    	}
	    		return modelAndView;
	    }
	  
	  @RequestMapping(value="existingProjects.html")
	  public ModelAndView existingProjects(/*@ModelAttribute Project project,*/HttpServletRequest request, HttpSession httpSession)
	  {
		  	logger.info("Opening existing projects");
		  	String emailId=(String)request.getSession().getAttribute("emailId"); 
		  	
		  	ModelAndView modelAndView=new ModelAndView();
		  
		  	int adminId=adminLoginService.getadminId(emailId);
	    	
	    	logger.info("Fetching project list");
		  	List<Project> project = adminLoginService.getProjects(adminId);
		  	Admin admin=adminLoginService.getAdmin(emailId);
		  	
		  	modelAndView.addObject("projectList", project);
	    		
		  	modelAndView.addObject("admin",admin);
	    	modelAndView.setViewName("existingProjects");	
	    	return modelAndView;
	  }
	  @RequestMapping(value="registerProject",method=RequestMethod.GET)
		public ModelAndView registerProject(@ModelAttribute Project project,HttpServletRequest request){
			ModelAndView modelAndView=new ModelAndView();
			logger.info("Validating minimum number of skills in a project ...");
			String emailId=(String)request.getSession().getAttribute("emailId");
			int adminId=adminLoginService.getadminId(emailId);
			String projectDuration=project.getProjectDuration();
			Admin admin=adminLoginService.getAdmin(emailId);
			modelAndView.addObject("admin",admin);
			boolean  duration= projectDuration.chars().allMatch(Character::isDigit);
			boolean flagDuration=false,flagBudget=false;
			if(!duration)
			{
				flagDuration=true;
				logger.info("Validation Failed");
				logger.info("**Project Duration cannot contain alphabet or special characters");
				modelAndView.addObject("statusProjectDuration","**Project Duration cannot contain alphabet or special characters");
			}
			List<String> skillList=new ArrayList<String>();
			skillList.add(project.getSkill1());
			skillList.add(project.getSkill2());
			skillList.add(project.getSkill3());
			skillList.add(project.getSkill4());
			skillList.add(project.getSkill5());
			skillList.add(project.getSkill6());
			skillList.add(project.getSkill7());
			skillList.add(project.getSkill8());
			skillList.add(project.getSkill9());
			skillList.add(project.getSkill10());
			Iterator it=skillList.iterator();
			int c=0;
			while(it.hasNext())
			{
				String string=(String) it.next();
				if(string==null)
				{
					c++;
				}
			}
			boolean flag=false;
			if(c==10){
				logger.warn("Validation of skill failed ! **Select atleast 1 skill");
				modelAndView.addObject("statusskill", "**Select atleast 1 skill");			
				flag=true;
			}
			if(flag==false&&flagDuration==false&&flagBudget==false)
			{logger.info("Project Skill validation Successfull ! ");
					boolean result=projectService.registerProject(project,adminId);
					logger.info("Adding project ...");
					if(result)
					{	
						modelAndView.addObject("name","Project "+project.getProjectName()+" added!");
						modelAndView.addObject("admin",admin);
						logger.info("Project Added !!");
					}
					else
					{	logger.warn("Project Registration failed !!");
						modelAndView.setViewName("error");	
					}
			}	
			modelAndView.setViewName("adminWelcome");
			return modelAndView;
		}
    @RequestMapping(value="acceptOffer")
    public ModelAndView acceptOffer(@RequestParam("id") int projectId,HttpServletRequest request, HttpSession httpSession)
    {
    	String emailId=(String)request.getSession().getAttribute("emailId");
    	
    	ModelAndView modelAndView=new ModelAndView();   
		int adminId=adminLoginService.getadminId(emailId);
    	
    	List<Project> projectList = adminLoginService.getProjects(adminId);
    	boolean result = adminLoginService.proposalResponse("Accepted",projectId);
    	int requesterId=adminLoginService.getProjectRequesterById(projectId);
    	Admin admin=adminLoginService.getAdmin(emailId);
    	Project project=lancerService.getProjectById(projectId);
    	String projectName=project.getProjectName();
    	int admId=project.getAdminId();
    	Proposals proposal=new Proposals();
    	proposal.setProjectId(projectId);
    	proposal.setAdminId(admId);
    	proposal.setUserId(requesterId);
    	proposal.setProjectName(projectName);
    	boolean proresult=adminLoginService.addproposal(proposal);
    	if(proresult==true)
    		System.out.println("added proposal!");
    	lancerService.setProposed(projectId, requesterId);
    	modelAndView.addObject("projectList", projectList);
    	modelAndView.addObject("admin",admin);
    	
    	modelAndView.setViewName("existingProjects");	
    	return modelAndView;
    }
    @RequestMapping(value="rejectOffer")
    public ModelAndView rejectOffer(@RequestParam("id") int projectId,HttpServletRequest request)
    {
    	String emailId=(String)request.getSession().getAttribute("emailId");
    	ModelAndView modelAndView=new ModelAndView();
    	int adminId=adminLoginService.getadminId(emailId);
    	List<Project> projectList = adminLoginService.getProjects(adminId);
    	boolean result=adminLoginService.proposalResponse("Rejected",projectId);
    	Admin admin=adminLoginService.getAdmin(emailId);
    	modelAndView.addObject("projectList", projectList);
    	modelAndView.addObject("admin",admin);
    	modelAndView.setViewName("existingProjects");	
    	return modelAndView;
    }
    
    @RequestMapping(value="logoutAdmin")
	public String lancerForm()
	{
		return "welcome";
    }
    
    @RequestMapping(value="deleteProject")
    public ModelAndView deleteProject(@RequestParam("id") int projectId,HttpServletRequest request)
    {
    	String emailId=(String)request.getSession().getAttribute("emailId");
    	Admin admin=adminLoginService.getAdmin(emailId);
    	ModelAndView modelAndView=new ModelAndView();
    	int adminId=adminLoginService.getadminId(emailId);
    	List<Project> projectList = adminLoginService.getProjects(adminId);
    	boolean result=projectService.deleteProject(projectId);
    	if(result)
    	{	logger.warn("Project Deleted !!");
    		modelAndView.setViewName("existingProjects");
    		modelAndView.addObject("admin",admin);
    		modelAndView.addObject("deletestatus","Project successfully deleted, Go back and refresh!");
    	}
    	else
    		modelAndView.setViewName("error");
    	return modelAndView;
    }
    @RequestMapping("addProject")
	 public ModelAndView addProject(HttpServletRequest request)
	  {
    	String emailId=(String)request.getSession().getAttribute("emailId");
    	Admin admin=adminLoginService.getAdmin(emailId);
    	ModelAndView modelAndView=new ModelAndView();
    	modelAndView.addObject(admin);
	    modelAndView.setViewName("adminWelcome");
	    return modelAndView;
	  }
    
    @RequestMapping(value="adminHome")
	public ModelAndView backToHome(HttpServletRequest request)
	{
    	String emailId=(String)request.getSession().getAttribute("emailId");
    	Admin admin=adminLoginService.getAdmin(emailId);
    	ModelAndView modelAndView=new ModelAndView();
    	modelAndView.addObject(admin);
	    modelAndView.setViewName("adminWelcome");
	    return modelAndView;
	}
    
}
