package com.cts.freelancer.dao;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.freelancer.bean.Admin;

@Repository
public class AdminUpdateDAOImpl implements AdminUpdateDAO {

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	@Transactional
	public boolean updatePhone(String uphone,int adminId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Admin where adminId=?");
		query.setParameter(0, adminId);
		Admin admin=(Admin)query.getSingleResult();
		admin.setPhoneNumber(uphone);
		return true;
	}
	@Transactional
	public boolean updatePassword(String upass,int adminId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Admin where adminId=?");
		query.setParameter(0, adminId);
		Admin admin=(Admin)query.getSingleResult();
		admin.setPassword(upass);
		return true;
	}

}
