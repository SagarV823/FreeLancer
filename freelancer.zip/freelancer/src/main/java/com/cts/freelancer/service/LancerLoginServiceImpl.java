package com.cts.freelancer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.freelancer.bean.Lancer;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.dao.LancerLoginDAO;

@Service("lancerLoginService")
@Transactional(propagation=Propagation.SUPPORTS)
public class LancerLoginServiceImpl implements LancerLoginService{

	@Autowired
	LancerLoginDAO lancerLogin;

	public boolean authenticate(String emailId, String password) {
		// TODO Auto-generated method stub
		return lancerLogin.authenticate(emailId, password);
	}

	public boolean registerLancer(Lancer lancer) {
		// TODO Auto-generated method stub
		return lancerLogin.registerLancer(lancer);
	}

	public List<Project> showProjects(String emailId) {
		// TODO Auto-generated method stub
		return lancerLogin.showProjects(emailId);
	}

	public Lancer getLancerSkills(String emailId) {
		// TODO Auto-generated method stub
		return lancerLogin.getLancerSkills(emailId);
	}

	public Project getProjectById(int id) {
		// TODO Auto-generated method stub
		return lancerLogin.getProjectById(id);
	}

	public int getlancerId(String emailId) {
		// TODO Auto-generated method stub
		return lancerLogin.getlancerId(emailId);
	}

	@Override
	public boolean sendRequest(int lancerid,int id) {
		// TODO Auto-generated method stub
		return lancerLogin.sendRequest(lancerid,id);
	}

	@Override
	public boolean authenticateUserExistence(String emailId) {
		// TODO Auto-generated method stub
		return lancerLogin.authenticateUserExistence(emailId);
	}

	@Override
	public boolean setProposed(int projectId, int requesterId) {
		return lancerLogin.setProposed(projectId, requesterId);
	}
}
