package com.cts.freelancer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.dao.ProjectDAO;

@Service("ProjectService")
@Transactional(propagation=Propagation.SUPPORTS)
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectDAO projectDAO;
	
	public boolean registerProject(Project project,int adminId) {
		return projectDAO.registerProject(project,adminId);
	}

	public boolean updateProjectSkills(int pid, List<String> skillList) {
		return projectDAO.updateProjectSkills(pid, skillList);
	}

	public boolean deleteProject(int projectId) {
		return projectDAO.deleteProject(projectId);
	}

	public boolean refreshProject(int projectId) {
		return projectDAO.refreshProject(projectId);
	}

}
