package com.cts.freelancer.service;

import java.util.List;

import com.cts.freelancer.bean.Lancer;
import com.cts.freelancer.bean.Project;

public interface LancerLoginService {

	public boolean registerLancer(Lancer lancer);
	public boolean authenticate(String emailId,String password);
	public Lancer getLancerSkills(String emailId);
	public List<Project> showProjects(String emailId);
	public int getlancerId(String emailId);
	public Project getProjectById(int id);
	public boolean sendRequest(int lancerid, int id);
	public boolean setProposed(int projectId,int requesterId);
	public boolean authenticateUserExistence(String emailId);
}
