package com.cts.freelancer.service;

import java.util.List;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.Proposals;

public interface AdminLoginService {
	public boolean authenticate(String emailId,String password);
	public boolean registerAdmin(Admin admin);
	public Admin getAdmin(String email);
	public int getadminId(String emailId);
	public int getProjectRequesterById(int id);
	public List<Project> getProjects(int adminId);
	public boolean proposalResponse(String response,int projectId);
	public boolean authenticateAdminExistence(String emailId);
	public boolean addproposal(Proposals proposal);
}
