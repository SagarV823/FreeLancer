package com.cts.freelancer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.freelancer.dao.AdminUpdateDAO;

@Service("AdminUpdateService")
@Transactional(propagation=Propagation.SUPPORTS)
public class AdminUpdateServiceImpl implements AdminUpdateService {
	
	@Autowired
	AdminUpdateDAO adminUpdate;
	
	@Override
	public boolean updatePhone(String uphone,int adminId) {
		return adminUpdate.updatePhone(uphone,adminId);
	}

	@Override
	public boolean updatePassword(String upass,int adminId) {
		// TODO Auto-generated method stub
		return adminUpdate.updatePassword(upass,adminId);
	}

}
