package com.cts.freelancer.dao;

import java.util.List;

import com.cts.freelancer.bean.Lancer;
import com.cts.freelancer.bean.Project;

public interface LancerLoginDAO {

	public boolean authenticate(String emailId,String password);
	public boolean registerLancer(Lancer lancer);
	public Lancer getLancerSkills(String emailId);
	public List<Project> showProjects(String emailId);
	public int getlancerId(String emailId);
	public Project getProjectById(int id);
	public boolean sendRequest(int id,int projectId);
	public boolean setProposed(int projectId,int requesterId);
	public boolean authenticateUserExistence(String emailId);
}
