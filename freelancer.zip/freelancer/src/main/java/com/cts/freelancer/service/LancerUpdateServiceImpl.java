package com.cts.freelancer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.freelancer.bean.Lancer;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.dao.LancerUpdateDAO;

@Service("lancerUpdateService")
@Transactional(propagation=Propagation.SUPPORTS)
public class LancerUpdateServiceImpl implements LancerUpdateService{

	@Autowired
	LancerUpdateDAO lancerupdate;
	
	@Override
	public boolean updateLancer(String lancerEmail,List<String> skillList) {
		return lancerupdate.updateLancer(lancerEmail,skillList);
	}
}
