package com.cts.freelancer.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Lancer;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.service.LancerLoginService;

@Controller
public class LancerController {
	
	@Autowired
	LancerLoginService lancerLogin;
	static Logger logger = Logger.getLogger(LancerController.class);
	@RequestMapping(value="registerLancer",method=RequestMethod.GET)
	public ModelAndView registerUser(@ModelAttribute Lancer lancer)
	{	boolean flagName=false,flagEmail=false,flagPhone=false,flagSkill=false;
			ModelAndView modelAndView=new ModelAndView();
			logger.info("Validating Inputs...");
			String firstName=lancer.getFirstName();
			String lastName=lancer.getLastName();
			String phoneNumber=lancer.getPhoneNumber();
			List<String> skillList=new ArrayList<String>();
			skillList.add(lancer.getSkill1());
			skillList.add(lancer.getSkill2());
			skillList.add(lancer.getSkill3());
			skillList.add(lancer.getSkill4());
			skillList.add(lancer.getSkill5());
			skillList.add(lancer.getSkill6());
			skillList.add(lancer.getSkill7());
			skillList.add(lancer.getSkill8());
			skillList.add(lancer.getSkill9());
			skillList.add(lancer.getSkill10());
			Iterator it=skillList.iterator();
			int count=0;
			boolean skill=false;
			while(it.hasNext())
			{
				if(it.next()=="NULL")
				{
					count++;
				}
			}
			if(count==10)
				skill=true;
			
			boolean allFirstLetters = firstName.chars().allMatch(Character::isLetter);
			boolean allLastLetters = lastName.chars().allMatch(Character::isLetter);
			if(count>0)
				logger.info("Validating minimum number of skills in a project ...");
			
			if(skill)
			{	logger.warn("Validation of skill failed ! **Select atleast 1 skill");
				modelAndView.addObject("statusskill", "**Select atleast 1 skill");
				flagSkill=true;
			}
			boolean result=lancerLogin.authenticateUserExistence(lancer.getEmailId());
			
			if(result==true){
				logger.info("Validation Failed");
				logger.info("**Email Id already exists");
				modelAndView.addObject("statusemail", "**Email Id already exists, try with different email id");flagEmail=true;}
			
			
			if(!allLastLetters){
				flagName=true;
				logger.info("Validation Failed");
				logger.info("**Last Name cannot contain number or special characters");
				modelAndView.addObject("statuslastname","**Last Name cannot contain number or special characters");
				}
			if(!allFirstLetters){
					flagName=true;
					logger.info("Validation Failed");
					logger.info("**First Name cannot contain number or special characters");
					modelAndView.addObject("statusfirstname","**First Name cannot contain number or special characters");
				}
			
			
			if((phoneNumber.length()>10||phoneNumber.length()<10)||(phoneNumber.contains("[a-zA-Z]+"))){
				
				if(phoneNumber.length()>10||phoneNumber.length()<10){
					
					if(phoneNumber.length()>10){
						flagPhone=true;
						logger.info("Validation Failed");
						logger.info("**Phone Number cannot be greater than 10 digits");
						modelAndView.addObject("statusphone","**Phone Number cannot be greater than 10 digits");
						}
					else if(phoneNumber.length()<10)
						{flagPhone=true;
						logger.info("Validation Failed");
						logger.info("**Phone Number cannot be less than 10 digits");
						modelAndView.addObject("statusphone","**Phone Number cannot be less than 10 digits");
						
						}
					}
				else if(phoneNumber.contains("[a-zA-Z]+"))
				{		flagPhone=true;
						logger.info("Validation Failed");
						logger.info("**Phone Number cannot contain alphabet or special characters");
						modelAndView.addObject("statusphone","**Phone Number cannot contain alphabet or special characters");
					
				}
			}
			
		
			logger.debug("Lflag Name : "+flagName);
			logger.debug("Lflag Email : "+flagEmail);
			logger.debug("Lflag Phone : "+flagPhone);
			logger.debug("Lflag skill : "+flagSkill);
		
		if(flagName==false&&flagEmail==false&&flagPhone==false&&flagSkill==false)
		{	boolean registerLancer=lancerLogin.registerLancer(lancer);
			if(registerLancer)
			logger.info("Registration successful !");
			else
				logger.warn("Registration failed ! Check EmailId or Password ...");
			modelAndView.addObject("Registerstatus","Successfully registered! Proceed to login Page!");
		}
		
		modelAndView.setViewName("lancerRegisterForm");
		return modelAndView;
	}

	@RequestMapping(value="lancerLoginAuth",method=RequestMethod.POST)
	public ModelAndView loginLancer(@RequestParam ("emailId") String emailId,@RequestParam ("password") String password,HttpServletRequest request)
	{	 
		
		ModelAndView modelAndView=new ModelAndView();
		List<Project> projectList=new ArrayList<Project>();
		logger.info("Credential L Authenticating ...");
		boolean result=lancerLogin.authenticate(emailId, password);
		if(result)
		{
			logger.info("Authentication Successful ...");	
			logger.info("generating session ...");
			HttpSession session=request.getSession(true);
			logger.info("Session generated ...");
			session.setAttribute("session", session.getId());
			request.getSession().setAttribute("LanceremailId",emailId);
			projectList=lancerLogin.showProjects(emailId);
			int lancerId=lancerLogin.getlancerId(emailId);
			session.setAttribute("lancerId",lancerId);
			modelAndView.addObject("projectList",projectList);
			Lancer lancer=lancerLogin.getLancerSkills(emailId);
			modelAndView.addObject("lancer",lancer);
			modelAndView.setViewName("lancerWelcome");	
		}
		else
		{	logger.warn("Authentication failed ! Wrong Email or Password ...");	
			modelAndView.addObject("status","Wrong EmailId or Password!");
			modelAndView.setViewName("lancerLogin");
		}
		return modelAndView;
	}
	@RequestMapping(value="requestPage")
	public ModelAndView RequestforProject(@SessionAttribute ("lancerId") int lancerId,@RequestParam("id") String id,HttpServletRequest request){
		ModelAndView modelAndView = new ModelAndView();
		int id1=Integer.parseInt(id);
		boolean result=lancerLogin.sendRequest(lancerId,id1);
		String lancerEmail=(String)request.getSession().getAttribute("LanceremailId");
		Lancer lancer=lancerLogin.getLancerSkills(lancerEmail);
		Project project=lancerLogin.getProjectById(id1);
		modelAndView.addObject("lancer",lancer);
		modelAndView.addObject("projectid",id);
		modelAndView.addObject("proposal","Proposal for Project Id : "+id+" successfully sent!");
		modelAndView.addObject("Refresh","To check its status kindly relogin!");
		modelAndView.addObject("project",project);
		if(result)
		{
			String skill1=project.getSkill1();
			String skill2=project.getSkill2();
			String skill3=project.getSkill3();
			String skill4=project.getSkill4();
			String skill5=project.getSkill5();
			String skill6=project.getSkill6();
			String skill7=project.getSkill7();
			String skill8=project.getSkill8();
			String skill9=project.getSkill9();
			String skill10=project.getSkill10();
			if(!skill1.equals("NULL"))
				modelAndView.addObject("skill1",project.getSkill1());
			if(!skill2.equals("NULL"))
				modelAndView.addObject("skill2",project.getSkill2());
			if(!skill3.equals("NULL"))
				modelAndView.addObject("skill3",project.getSkill3());
			if(!skill4.equals("NULL"))
				modelAndView.addObject("skill4",project.getSkill4());
			if(!skill5.equals("NULL"))
				modelAndView.addObject("skill5",project.getSkill5());
			if(!skill6.equals("NULL"))
				modelAndView.addObject("skill6",project.getSkill6());
			if(!skill7.equals("NULL"))
				modelAndView.addObject("skill7",project.getSkill7());
			if(!skill8.equals("NULL"))
				modelAndView.addObject("skill8",project.getSkill8());
			if(!skill9.equals("NULL"))	
				modelAndView.addObject("skill9",project.getSkill9());
			if(!skill10.equals("NULL"))
				modelAndView.addObject("skill10",project.getSkill10());	
			modelAndView.setViewName("projectDetails");
		}
			
		return modelAndView;
	}
	@RequestMapping(value="projectDetailsPage")
	public ModelAndView ViewProject(@RequestParam("id") int id,HttpSession httpSession,HttpServletRequest request){
		ModelAndView modelAndView = new ModelAndView();
		Project project= lancerLogin.getProjectById(id);
		String lancerEmail=(String)request.getSession().getAttribute("LanceremailId");
		modelAndView.addObject("project",project);
		String skill1=project.getSkill1();
		String skill2=project.getSkill2();
		String skill3=project.getSkill3();
		String skill4=project.getSkill4();
		String skill5=project.getSkill5();
		String skill6=project.getSkill6();
		String skill7=project.getSkill7();
		String skill8=project.getSkill8();
		String skill9=project.getSkill9();
		String skill10=project.getSkill10();
		if(!skill1.equals("NULL"))
			modelAndView.addObject("skill1",project.getSkill1());
		if(!skill2.equals("NULL"))
			modelAndView.addObject("skill2",project.getSkill2());
		if(!skill3.equals("NULL"))
			modelAndView.addObject("skill3",project.getSkill3());
		if(!skill4.equals("NULL"))
			modelAndView.addObject("skill4",project.getSkill4());
		if(!skill5.equals("NULL"))
			modelAndView.addObject("skill5",project.getSkill5());
		if(!skill6.equals("NULL"))
			modelAndView.addObject("skill6",project.getSkill6());
		if(!skill7.equals("NULL"))
			modelAndView.addObject("skill7",project.getSkill7());
		if(!skill8.equals("NULL"))
			modelAndView.addObject("skill8",project.getSkill8());
		if(!skill9.equals("NULL"))	
			modelAndView.addObject("skill9",project.getSkill9());
		if(!skill10.equals("NULL"))
			modelAndView.addObject("skill10",project.getSkill10());	
		Lancer lancer=lancerLogin.getLancerSkills(lancerEmail);
		modelAndView.addObject("lancer",lancer);
		modelAndView.setViewName("projectDetails");
		return modelAndView;
	}
	@RequestMapping("lancerHome")
	 public ModelAndView addProject(HttpServletRequest request)
	  {
		List<Project> projectList=new ArrayList<Project>(); 
		String lancerEmail=(String)request.getSession().getAttribute("LanceremailId");
		Lancer lancer=lancerLogin.getLancerSkills(lancerEmail);
		projectList=lancerLogin.showProjects(lancerEmail);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject(lancer);
		modelAndView.addObject("projectList",projectList);
	    modelAndView.setViewName("lancerWelcome");
	    return modelAndView;
	  }
	
	@RequestMapping(value="logoutLancer")
	public String logoutPage()
	{
		return "welcome";
	}
}
