package com.cts.freelancer.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Lancer;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.Proposals;

@Repository("adminLoginDAO")

public class AdminLoginDAOImpl implements AdminLoginDAO{
	
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;

	@org.springframework.transaction.annotation.Transactional(readOnly=true)
	public boolean authenticate(String emailId, String password) {
		try
		{
			Session session = sessionFactory.getCurrentSession();
			Query query=session.createQuery("from Admin where emailId=? and password=?");
			query.setParameter(0,emailId);
			query.setParameter(1,password);
			Admin admin=(Admin)query.getSingleResult();
			return true;
		}
		catch(NoResultException e)
		{
			System.out.println("no result");
			System.out.println(e);
			return false;
		}
		
	}

	@Transactional
	public boolean registerAdmin(Admin admin) {
		Session session=null;
    		try{
    			session=sessionFactory.getCurrentSession();
    			session.save(admin);
    			
    		}catch(Exception e)
    		{
    			e.printStackTrace();
    			return false;
    		}
    		return true;
    		
    	}

	@javax.transaction.Transactional
	public List<Project> getProjects(int adminId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Project where adminId=?");
		query.setParameter(0,adminId);
		System.out.println(adminId);
		List<Project> projectList=query.getResultList();
		for(Project p:projectList)
		{
			System.out.println(p.getAdminId());
		}
		return projectList;
	}

	@javax.transaction.Transactional
	public int getadminId(String emailId) {
		try
		{
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Admin where emailId=?");
		query.setParameter(0,emailId);
		Admin admin=(Admin)query.getSingleResult();
		int adminId=admin.getAdminId();
		return adminId;
		}
		catch (Exception e) {
			// TODO: handle exception
			return 0;
		}
	}

	@javax.transaction.Transactional
	public boolean proposalResponse(String response,int projectid) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Project where projectId=?");
		query.setParameter(0,projectid);
		System.out.println(response);
		System.out.println(projectid);
		Project project=(Project)query.getSingleResult();
		if(project.getRequestId()!=0)
			project.setStatus(response);
		else
			return false;
		return true;
	}

	@Transactional
	public Admin getAdmin(String email) {
		try{
		Session session = sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Admin where emailId=?");
		query.setParameter(0,email);
		Admin admin=(Admin)query.getSingleResult();
		return admin;
		}
		catch(NoResultException e)
		{
			return null;
		}
		
	}

	@javax.transaction.Transactional
	public boolean authenticateAdminExistence(String emailId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Query query=session.createQuery("from Admin where emailId=?");
			query.setParameter(0,emailId);
			Admin admin=(Admin)query.getSingleResult();
		}
		catch(NoResultException e)
		{
			return false;
		}
		return true;
	}

	@Transactional
	public int getProjectRequesterById(int id) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Project where projectId=?");
		query.setParameter(0,id);
		Project project=(Project)query.getSingleResult();
		int requesterId=project.getRequestId();
		return requesterId;
	}

	@Transactional
	public boolean addproposal(Proposals proposal) {
		try{
			Session session=null;
			session=sessionFactory.getCurrentSession();
			session.persist(proposal);
		}
		catch(Exception e)
    	{
    		e.printStackTrace();
    		return false;
    	}
		return true;
	}
}

	

	

