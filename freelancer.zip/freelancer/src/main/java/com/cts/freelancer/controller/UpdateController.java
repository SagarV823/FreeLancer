package com.cts.freelancer.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.service.AdminLoginService;
import com.cts.freelancer.service.AdminUpdateService;
import com.cts.freelancer.service.LancerLoginService;
import com.cts.freelancer.service.LancerUpdateService;
import com.cts.freelancer.service.ProjectService;

@Controller
@Scope("session")
public class UpdateController {

	@Autowired
	AdminUpdateService adminUpdate;
	
	@Autowired
	LancerLoginService lancerLoginService;
	
	@Autowired
	AdminLoginService adminLoginService;
	
	@Autowired
	ProjectService projectService;
	
	@Autowired
	LancerUpdateService lancerUpdate;
	static Logger logger = Logger.getLogger(UpdateController.class);
	
	@RequestMapping(value="UpdateAdminPhone",method=RequestMethod.POST)
	public ModelAndView updatePhone(@RequestParam("phoneNumber") String phone,HttpServletRequest request){
		ModelAndView modelAndView=new ModelAndView();
		boolean flagPhone=false;
		String emailId=(String)request.getSession().getAttribute("emailId");
		Admin admin=adminLoginService.getAdmin(emailId);
		String phoneNumber=phone;
		if((phoneNumber.length()>10||phoneNumber.length()<10)||(phoneNumber.contains("[a-zA-Z]+"))){
			if(phoneNumber.length()>10||phoneNumber.length()<10){
				if(phoneNumber.length()>10){
					flagPhone=true;
					logger.info("Validation Failed");
					logger.info("**Phone Number cannot be greater than 10 digits");
					modelAndView.addObject("statusphone","**Phone Number cannot be greater than 10 digits");
					modelAndView.setViewName("updateAdmin");
					}
				else if(phoneNumber.length()<10)
					{flagPhone=true;
					logger.info("Validation Failed");
					logger.info("**Phone Number cannot be less than 10 digits");
					modelAndView.addObject("statusphone","**Phone Number cannot be less than 10 digits");
					modelAndView.setViewName("updateAdmin");
					}
				}
			else if(phoneNumber.contains("[a-zA-Z]+"))
			{flagPhone=true;
			logger.info("Validation Failed");
			logger.info("**Phone Number cannot contain alphabet or special characters");
				modelAndView.addObject("statusphone","**Phone Number cannot contain alphabet or special characters");
				modelAndView.setViewName("updateAdmin");
			}
			
		}
		
			
			if(flagPhone==false){
				int adminId=adminLoginService.getadminId(emailId);
				boolean result=adminUpdate.updatePhone(phone,adminId);
				if(result)
				{	logger.info("Phone number Updated ...");
					modelAndView.addObject("admin",admin);
					modelAndView.setViewName("adminWelcome");
				}
			}
		
		return modelAndView;		
	}
	@RequestMapping(value="UpdateAdminPassword",method=RequestMethod.POST)
	public ModelAndView updatePass(@RequestParam("password") String pass,HttpServletRequest request){
		ModelAndView modelAndView=new ModelAndView();
		String emailId=(String)request.getSession().getAttribute("emailId");
		int adminId=adminLoginService.getadminId(emailId);
		Admin admin=adminLoginService.getAdmin(emailId);
		boolean result=adminUpdate.updatePassword(pass,adminId);
		if(result)
		{	logger.info("Admin Password Updated ...");
			modelAndView.addObject("admin",admin);
			modelAndView.setViewName("adminWelcome");
		}else
			logger.warn("Admin Password Updation failed ...");
		return modelAndView;		
	}
	@RequestMapping(value="UpdateLancer",method=RequestMethod.POST)
	public ModelAndView updateLancer(HttpServletRequest request){
		
		ModelAndView modelAndView=new ModelAndView();
		String skill1 = request.getParameter("skill1");
		String skill2=request.getParameter("skill2");
		String skill3=request.getParameter("skill3");
		String skill4=request.getParameter("skill4");
		String skill5=request.getParameter("skill5");
		String skill6=request.getParameter("skill6");
		String skill7=request.getParameter("skill7");
		String skill8=request.getParameter("skill8");
		String skill9=request.getParameter("skill9");
		String skill10=request.getParameter("skill10");
		String lancerEmail=(String)request.getSession().getAttribute("LanceremailId");
		List<String> skillList=new ArrayList<>();
		skillList.add(skill1);
		skillList.add(skill2);
		skillList.add(skill3);
		skillList.add(skill4);
		skillList.add(skill5);
		skillList.add(skill6);
		skillList.add(skill7);
		skillList.add(skill8);
		skillList.add(skill9);
		skillList.add(skill10);
		Iterator it=skillList.iterator();
		int count=0;
		while(it.hasNext())
		{
			String s=(String) it.next();
			if(s.equals("NULL"))
				count++;
		}
		if(count==10)
		{
			logger.warn("Validation of skill failed ! **Select atleast 1 skill");
			modelAndView.addObject("statusskill", "**Select atleast 1 skill");
			modelAndView.setViewName("updateLancer");
		}
		else{
			boolean result=lancerUpdate.updateLancer(lancerEmail, skillList);
			if(result)
			{	logger.info("Skill updation successfull !");
				modelAndView.setViewName("updateLancer");
				modelAndView.addObject("updateStatus","Updated successfully, Now check your projects!");
			}else
				logger.warn("Skill updation failed!");
		}
		return modelAndView;
	}
	@RequestMapping(value="updateProjectSkills",method=RequestMethod.POST)
	public ModelAndView updateProjectSkills(@RequestParam("id") int id,HttpServletRequest request){
		ModelAndView modelAndView=new ModelAndView();
		String emailId=(String)request.getSession().getAttribute("emailId");
		int adminId=adminLoginService.getadminId(emailId);
		String skill1=request.getParameter("skill1");
		String skill2=request.getParameter("skill2");
		String skill3=request.getParameter("skill3");
		String skill4=request.getParameter("skill4");
		String skill5=request.getParameter("skill5");
		String skill6=request.getParameter("skill6");
		String skill7=request.getParameter("skill7");
		String skill8=request.getParameter("skill8");
		String skill9=request.getParameter("skill9");
		String skill10=request.getParameter("skill10");
		List<String> skillList=new ArrayList<>();
		skillList.add(skill1);
		skillList.add(skill2);
		skillList.add(skill3);
		skillList.add(skill4);
		skillList.add(skill5);
		skillList.add(skill6);
		skillList.add(skill7);
		skillList.add(skill8);
		skillList.add(skill9);
		skillList.add(skill10);
		Iterator it=skillList.iterator();
		int count=0;
		while(it.hasNext())
		{
			String s=(String) it.next();
			if(s.equals("NULL"))
				count++;
		}
		if(count==10)
		{
			logger.warn("Validation of skill failed ! **Select atleast 1 skill");
			modelAndView.addObject("statusskill", "**Select atleast 1 skill");
			modelAndView.setViewName("updateProjectPage");
		}
		else{
			boolean result=projectService.updateProjectSkills(id,skillList);
			
			if(result){
				logger.info("Project Skills successfully updated !");
				modelAndView.addObject("updatestatus","Project skills successfully updated!");
				modelAndView.setViewName("updateProjectPage");
			}else
				logger.warn("Project kills updation failed ...");
		}
		
		return modelAndView;		
	}
	@RequestMapping(value="refreshProject",method=RequestMethod.GET)
	public ModelAndView refreshProject(@RequestParam("id") int id,HttpServletRequest request){
			ModelAndView modelAndView=new ModelAndView();
			boolean result=projectService.refreshProject(id);
			String emailId=(String)request.getSession().getAttribute("emailId");
			Admin admin=adminLoginService.getAdmin(emailId);
			int adminId=admin.getAdminId();
			List<Project> projectList = adminLoginService.getProjects(adminId);
			if(result==true)
				{
					modelAndView.addObject("projectList", projectList);
					modelAndView.addObject("admin",admin);
					modelAndView.setViewName("existingProjects");
					System.out.println("Project successfully refreshed!");
				}
		return modelAndView;
	}
	
}
