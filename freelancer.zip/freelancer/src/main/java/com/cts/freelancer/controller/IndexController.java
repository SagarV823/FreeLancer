package com.cts.freelancer.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.service.LancerLoginService;

@Controller
public class IndexController {
	static Logger logger=Logger.getLogger(IndexController.class);
	@Autowired
	LancerLoginService lancerLoginService;
	
	@RequestMapping(value="/")
	public String welcomePage()
	{
		return "welcome";
	}
	
	@RequestMapping(value="homePage")
	public String homePage()
	{
		return "welcome";
	}
   
	@RequestMapping(value="lancerLoginPage")
	public String lancerForm()
	{
		return "lancerLogin";
    }
	
	@RequestMapping("adminLoginPage")
	  public String loginAdminScreen()
	  {
		  return "adminLogin";
	  }
	  
	  @RequestMapping("adminRegisterPage")
	  public String adminRegisterPage()
	  {
		  return "adminRegisterForm";
	  }
	  
	  @RequestMapping("lancerRegisterPage")
	  public String lancerRegisterPage()
	  {
		  return "lancerRegisterForm";
	  }
	  
	  @RequestMapping("updateAdminPage")
	  public String updateAdminPage()
	  {
	      return "updateAdmin";
	  }
	  
	  @RequestMapping("updateLancerPage")
	  public String updateLancerPage()
	  {
	      return "updateLancer";
	  }
	  
	  
	  @RequestMapping(value="updateProjectPage",method=RequestMethod.GET)
	  public ModelAndView updateProject(@RequestParam("id") int id,HttpServletRequest request)
	  {
				ModelAndView modelAndView=new ModelAndView();
				Project project=lancerLoginService.getProjectById(id);
				logger.info("Project Updated!");
				modelAndView.addObject("project",project);
				modelAndView.setViewName("updateProjectPage");
				return modelAndView;
	  }
	  	  
	  @RequestMapping("aboutUs")
	  public String aboutUsPage()
	  {
	      return "aboutUs";
	  }
	  
}
