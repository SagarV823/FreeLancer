package com.cts.freelancer.dao;

public interface AdminUpdateDAO {
	
	public boolean updatePhone(String uphone,int adminId);
	public boolean updatePassword(String upass,int adminId);

}
