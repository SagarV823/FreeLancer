package com.cts.freelancer.service;

import java.util.List;

public interface LancerUpdateService {
	
	public boolean updateLancer(String lancerEmail,List<String> skillList);
}