package com.cts.freelancer.dao;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.freelancer.bean.Lancer;
import com.cts.freelancer.bean.Project;

@Repository("ProjectDAO")
public class ProjectDAOImpl implements ProjectDAO{

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	@Transactional
	public boolean registerProject(Project project,int adminId) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		project.setAdminId(adminId);
		session.save(project);
		return true;
	}

	@Transactional
	public boolean updateProjectSkills(int pid, List<String> skillList) {
		Session session=sessionFactory.getCurrentSession();
		String skill1=skillList.get(0);
		String skill2=skillList.get(1);
		String skill3=skillList.get(2);
		String skill4=skillList.get(3);
		String skill5=skillList.get(4);
		String skill6=skillList.get(5);
		String skill7=skillList.get(6);
		String skill8=skillList.get(7);
		String skill9=skillList.get(8);
		String skill10=skillList.get(9);
		Query query=session.createQuery("from Project where projectId=?");
		query.setParameter(0,pid);
		Project project=(Project)query.getSingleResult();
		project.setSkill1(skill1);
		project.setSkill2(skill2);
		project.setSkill3(skill3);
		project.setSkill4(skill4);
		project.setSkill5(skill5);
		project.setSkill6(skill6);
		project.setSkill7(skill7);
		project.setSkill8(skill8);
		project.setSkill9(skill9);
		project.setSkill10(skill10);
		return true;
	}

	@Transactional
	public boolean deleteProject(int projectId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Project where projectId=?");
		query.setParameter(0, projectId);
		Project project=(Project)query.getSingleResult();
		session.delete(project);
		return true;
	}

	@Transactional
	public boolean refreshProject(int projectId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Project where projectId=?");
		query.setParameter(0, projectId);
		Project project=(Project)query.getSingleResult();
		project.setStatus("Not yet proposed!");
		project.setRequestId(0);
		System.out.println("project requester "+project.getRequestId());
		return true;
	}

}
