package com.cts.freelancer.dao;

import java.util.List;

public interface LancerUpdateDAO {
	public boolean updateLancer(String lancerEmail,List<String> skillList);
}
