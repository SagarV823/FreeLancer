package com.cts.freelancer.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.NoResultException;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Lancer;
import com.cts.freelancer.bean.Project;


@Repository("LancerLoginDAO")
public class LancerLoginDAOImpl implements LancerLoginDAO{

	
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;

	@Transactional
	public boolean authenticate(String emailId, String password) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Query query=session.createQuery("from Lancer where emailId=? and password=?");
			query.setParameter(0,emailId);
			query.setParameter(1,password);
			Lancer lancer=(Lancer)query.getSingleResult();
			return true;
		}
		catch(NoResultException e)
		{
			return false;
		}
		
	}

    @Transactional
	public boolean registerLancer(Lancer lancer) {
		Session session=null;
				
    			session=sessionFactory.getCurrentSession();
    			session.save(lancer);
    			return true;
    		
    	}
    	
	
	@Transactional
	public List<Project> showProjects(String emailId) {

	     List<Project> projectList=new ArrayList<Project>();
	     //Set<Project> pro=new HashSet<Project>();
	     Session session=null;
	     try
	     {
	    	 Lancer lancer=getLancerSkills(emailId);
	    	 System.out.println("Returned user emailId = "+lancer.getEmailId()+" and userId ="+lancer.getUserId());
	    	 session=sessionFactory.getCurrentSession();
	    	 List<String> userskills=new ArrayList<String>();	    	 
	    	 String skill1=lancer.getSkill1();
	    	 String skill2=lancer.getSkill2();
	    	 String skill3=lancer.getSkill3();
	    	 String skill4=lancer.getSkill4();
	    	 String skill5=lancer.getSkill5();
	    	 String skill6=lancer.getSkill6();
	    	 String skill7=lancer.getSkill7();
	    	 String skill8=lancer.getSkill8();
	    	 String skill9=lancer.getSkill9();
	    	 String skill10=lancer.getSkill10();
	    	 
	    	 if(skill1.equals("PHP"))
	    		 userskills.add(skill1);
	    	 if(skill2.equals("HTML"))
	    		 userskills.add(skill2);
	    	 if(skill3.equals("Javascript"))
	    		 userskills.add(skill3);
	    	 if(skill4.equals("MySQL"))
	    		 userskills.add(skill4);
	    	 if(skill5.equals("Java"))
	    		 userskills.add(skill5);
	    	 if(skill6.equals("Python"))
	    		 userskills.add(skill6);
	    	 if(skill7.equals(".NET"))
	    		 userskills.add(skill7);
	    	 if(skill8.equals("Angular.js"))
	    		 userskills.add(skill8);
	    	 if(skill9.equals("Unity 3D"))
	    		 userskills.add(skill8);
	    	 if(skill10.equals("Laravel"))
	    		 userskills.add(skill10);
	    	 
	    	 int count=userskills.size();
	    	 System.out.println("UserSkill List size =" +count);
	          for(String s:userskills)
	        	  System.out.println(s);
	    	List<Project> allProjects=getAllProject();
	   
	    	for(Project pro:allProjects)
	    	{
	    		List<String> proSkills=projectSkills(pro);
	    		int size=0;
	    		for(String skill:proSkills)
	    		{
	    			if(userskills.contains(skill))
	    				size++;
	    		}
	    		if(size==proSkills.size())
	    			{
	    				if((pro.getStatus().equals("Not yet proposed!")&&pro.getRequestId()==0) ||
	    					(pro.getStatus().equals("Accepted")&&pro.getRequestId()==lancer.getUserId())||
	    					(pro.getStatus().equals("Rejected")&&pro.getRequestId()==lancer.getUserId())||
	    					(pro.getStatus().equals("Waiting for response")&&pro.getRequestId()==lancer.getUserId())
	    					)      
	    				{
	    					projectList.add(pro);
	    				}
	    				if(pro.getStatus().equals("Not yet proposed!"))
	    					System.out.println("Not yet proposed");
	    			}
	    	}	    	 
	     }
	     catch(Exception e)
	     {
	    	 e.printStackTrace();
	     }
	     return projectList;
	}

	@Transactional
	public Lancer getLancerSkills(String emailId) {
		Session session=sessionFactory.getCurrentSession();
    	Query query=session.createQuery("from Lancer where emailId=?");
    	query.setParameter(0,emailId);
    	Lancer lancer=(Lancer)query.getSingleResult();
		return lancer;
	}

	@Transactional
	public Project getProjectById(int id) {	
		try {
			Session session = sessionFactory.getCurrentSession();
			Query<Project> query=session.createQuery("from Project where projectId = ?");
			query.setParameter(0,id);
			Project project = (Project)query.getSingleResult();
			if(project==null)
				return null;
			else
				return project;
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return null;
	}

	@Transactional
	public int getlancerId(String emailId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Lancer where emailId=?");
		query.setParameter(0,emailId);
		Lancer lancer=(Lancer)query.getSingleResult();
		int lancerId=lancer.getUserId();
		System.out.println(lancerId);
		return lancerId;
	}
	
	@Transactional
	public boolean sendRequest(int lancerid,int id) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Project where projectId=?");
		query.setParameter(0,id);
	    Project project=(Project)query.uniqueResult();
	    project.setRequestId(lancerid);
	    project.setStatus("Waiting for response");
	    session.update(project);
	    return true;
		}
	
	@Transactional
	public List<Project> getAllProject() {
		// TODO Auto-generated method stub
		List<Project> allProjects=new ArrayList<>();
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Project");
		allProjects=query.getResultList();
		return allProjects;
	}
		
	@Transactional
	public List<String> projectSkills(Project project)
	{
		List<String> skills=new ArrayList<>();
		if(project.getSkill1().equals("PHP"))
   		 skills.add(project.getSkill1());
   	 if(project.getSkill2().equals("HTML"))
   		 skills.add(project.getSkill2());
   	 if(project.getSkill3().equals("Javascript"))
   		 skills.add(project.getSkill3());
   	 if(project.getSkill4().equals("MySQL"))
   		 skills.add(project.getSkill4());
   	 if(project.getSkill5().equals("Java"))
   		 skills.add(project.getSkill5());
   	 if(project.getSkill6().equals("Python"))
   		 skills.add(project.getSkill6());
   	 if(project.getSkill7().equals(".NET"))
   		 skills.add(project.getSkill7());
   	 if(project.getSkill8().equals("Angular.js"))
   		 skills.add(project.getSkill8());
   	 if(project.getSkill9().equals("Unity 3D"))
   		 skills.add(project.getSkill9());
   	 if(project.getSkill10().equals("Laravel"))
   		 skills.add(project.getSkill10());
		return skills;
	}

	@Transactional	
	public boolean authenticateUserExistence(String emailId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Query query=session.createQuery("from Lancer where emailId=?");
			query.setParameter(0,emailId);
			Lancer lancer=(Lancer)query.getSingleResult();
		}
		catch(NoResultException e)
		{
			return false;
		}
		return true;
	}

	@Transactional
	public boolean setProposed(int projectId, int requesterId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("update Lancer l set l.proposedProject=? where l.userId=?");
		query.setParameter(0, projectId);
		query.setParameter(1, requesterId);
		int res = query.executeUpdate();
		if(res>0)
		return true;
		return false;
	}
}
