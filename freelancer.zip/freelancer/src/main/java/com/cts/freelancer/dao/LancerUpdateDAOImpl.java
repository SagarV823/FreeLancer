package com.cts.freelancer.dao;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.freelancer.bean.Lancer;

@Repository
public class LancerUpdateDAOImpl implements LancerUpdateDAO {
	
	@Autowired
	SessionFactory sessionfactory;
	
	@Transactional
	public boolean updateLancer(String lancerEmail,List<String> skillList) {
		Session session=sessionfactory.getCurrentSession();
		String skill1=skillList.get(0);
		String skill2=skillList.get(1);
		String skill3=skillList.get(2);
		String skill4=skillList.get(3);
		String skill5=skillList.get(4);
		String skill6=skillList.get(5);
		String skill7=skillList.get(6);
		String skill8=skillList.get(7);
		String skill9=skillList.get(8);
		String skill10=skillList.get(9);
		Query query=session.createQuery("from Lancer where emailId=?");
		query.setParameter(0,lancerEmail);
		Lancer lancer=(Lancer)query.getSingleResult();
		lancer.setSkill1(skill1);
		lancer.setSkill2(skill2);
		lancer.setSkill3(skill3);
		lancer.setSkill4(skill4);
		lancer.setSkill5(skill5);
		lancer.setSkill6(skill6);
		lancer.setSkill7(skill7);
		lancer.setSkill8(skill8);
		lancer.setSkill9(skill9);
		lancer.setSkill10(skill10);
		return true;
	}
}
